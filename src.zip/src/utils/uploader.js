const fs = require("fs");
const mysql = require("mysql");
const fastcsv = require("fast-csv");

let stream = fs.createReadStream("./csv/products.csv");
let csvData = [];
let csvStream = fastcsv
    .parse()
    .on("data", function (data) {
        csvData.push(data);
    })
    .on("end", function () {
        csvData.shift();
        const connection = mysql.createConnection({
            host: "localhost",
            user: "root",
            password: "qwerty11",
            database: "usopp",
        });
        connection.connect((error) => {
            if (error) {
                console.error(error);
            } else {
                let query =
                    "INSERT INTO products (name,description,price,size,ingredient,detailed_ingredient,type,category_id,product_image_id) VALUES ?";
                connection.query(query, [csvData], (error, response) => {
                    console.log(error || response);
                });
            }
        });
    });
stream.pipe(csvStream);
