const userService = require("../services/userService");

const emailCheck = async (req, res) => {
    try {
        const { email } = req.body;
        if (!email) {
            return res.status(400).json({ message: "KEY_ERROR" });
        }
        await userService.emailCheck(email);

        res.status(201).json({ message: email });
    } catch (err) {
        res.status(err.statusCode ? err.statusCode : 400).json({
            message: err.message,
        });
    }
};

const signUp = async (req, res) => {
    try {
        const { email, password, first_name, last_name } = req.body;

        if (!first_name || !last_name || !email || !password) {
            return res.status(400).json({ message: "KEY_ERROR" });
        }

        await userService.signUp(email, password, first_name, last_name);

        res.status(201).json({ message: "USER_CREATED" });
    } catch (err) {
        res.status(err.statusCode ? err.statusCode : 400).json({
            message: err.message,
        });
    }
};

const signIn = async (req, res) => {
    try {
        const { email, password } = req.body;

        const accessToken = await userService.signIn(email, password);

        res.status(200).json({ accessToken: accessToken });
    } catch (err) {
        res.status(err.statusCode ? err.statusCode : 401).json({
            message: err.message,
        });
    }
};

module.exports = {
    signUp,
    signIn,
    emailCheck,
};
