const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const userDao = require("../models/userDao");
const { validateEmailPw } = require("../utils/userValidators");

const emailCheck = async (email) => {
    // validateEmailPw(email);

    const userEmail = userDao.emailCheck(email);
    console.log("email: " + email);

    if (userEmail) {
        console.log("YES EMAIL: " + email);
        // const err = new Error("EMAIL_ALREADY EXISTS");
        // err.statusCode = 201;
        // throw err;
    } else if (!userEmail) {
        console.log("NOT EMAIL: " + email);
        // const err = new Error("EMAIL_NO EXISTS");
        // err.statusCode = 404;
        // throw err;
    }
};

const signUp = async (email, password, first_name, last_name) => {
    // validateEmailPw(email, password);
    const userEmail = userDao.emailCheck(email);
    if (userEmail) {
        const err = new Error("EMAIL_ALREADY EXISTS");
        err.statusCode = 409;
        throw err;
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const createUser = await userDao.createUser(
        email,
        hashedPassword,
        first_name,
        last_name
    );

    return createUser;
};

const signIn = async (email, password) => {
    const user = await userDao.emailCheck(email);
    if (!user) {
        const err = new Error("EMAIL_OR_PASSWORD_IS_DIFFERENT");
        err.statusCode = 400;
        throw err;
    }
    const result = await bcrypt.compare(password, user[0].password);
    if (!result) {
        const err = new Error("EMAIL_OR_PASSWORD_IS_DIFFERENT");
        err.statusCode = 400;
        throw err;
    }

    const accessToken = jwt.sign({ email }, process.env.JWT_SECRET);

    return accessToken;
};

module.exports = {
    signUp,
    signIn,
    emailCheck,
};
