const database = require("./datasource");

const emailCheck = async (email) => {
    const user = await database.query(
        `
        SELECT email FROM users WHERE users.email = ?
        `,
        [email]
    );
    return user;
};

// const emailCheck = async (email) => {
//     const [result] = await database.query(
//         `
//         SELECT * FROM users
//         WHERE EXISTS
//         (SELECT email
//         FROM users
//         WHERE users.email = "${email}")
//         `
//     );
//     console.log("result :" + result);
//     return result;
// };

const createUser = async (email, password, first_name, last_name) => {
    const user = await database.query(
        `
        INSERT INTO users(
            email,
            password,
            first_name,
            last_name
        ) VALUES ( ?, ?, ?, ? )
        `,
        [email, password, first_name, last_name]
    );
    return user;
};

module.exports = {
    emailCheck,
    createUser,
};
